/* ICO encoder: BMP (4/8/24/32-bit) and PNG entries. No dependencies. */
(function (root) {
  'use strict';

  function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

  function medianCut(data, n) {
    var bins = new Map();
    for (var i = 0; i < data.length; i += 4) {
      if (data[i + 3] < 128) continue;
      var r = data[i], g = data[i + 1], b = data[i + 2];
      var k = ((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3);
      var e = bins.get(k);
      if (!e) { e = { r: 0, g: 0, b: 0, n: 0 }; bins.set(k, e); }
      e.r += r; e.g += g; e.b += b; e.n++;
    }
    var items = [];
    bins.forEach(function (e) { items.push({ r: e.r / e.n, g: e.g / e.n, b: e.b / e.n, n: e.n }); });
    if (!items.length) return [[0, 0, 0]];

    function mkBox(it) {
      var mn = [255, 255, 255], mx = [0, 0, 0];
      for (var j = 0; j < it.length; j++) {
        var v = [it[j].r, it[j].g, it[j].b];
        for (var c = 0; c < 3; c++) { if (v[c] < mn[c]) mn[c] = v[c]; if (v[c] > mx[c]) mx[c] = v[c]; }
      }
      var ch = 0, rg = -1;
      for (var c2 = 0; c2 < 3; c2++) { var d = mx[c2] - mn[c2]; if (d > rg) { rg = d; ch = c2; } }
      return { it: it, ch: ch, rg: rg };
    }

    var boxes = [mkBox(items)];
    while (boxes.length < n) {
      var bi = -1, best = 0;
      for (var q = 0; q < boxes.length; q++) {
        if (boxes[q].it.length > 1 && boxes[q].rg > best) { best = boxes[q].rg; bi = q; }
      }
      if (bi < 0) break;
      var box = boxes[bi], key = ['r', 'g', 'b'][box.ch];
      box.it.sort(function (a, b) { return a[key] - b[key]; });
      var total = 0, j2;
      for (j2 = 0; j2 < box.it.length; j2++) total += box.it[j2].n;
      var acc = 0, cut = 0;
      for (j2 = 0; j2 < box.it.length; j2++) { acc += box.it[j2].n; if (acc >= total / 2) { cut = j2 + 1; break; } }
      if (cut <= 0 || cut >= box.it.length) cut = Math.floor(box.it.length / 2);
      boxes.splice(bi, 1, mkBox(box.it.slice(0, cut)), mkBox(box.it.slice(cut)));
    }
    return boxes.map(function (b) {
      var sr = 0, sg = 0, sb = 0, sn = 0;
      for (var j = 0; j < b.it.length; j++) {
        var e = b.it[j];
        sr += e.r * e.n; sg += e.g * e.n; sb += e.b * e.n; sn += e.n;
      }
      return [Math.round(sr / sn), Math.round(sg / sn), Math.round(sb / sn)];
    });
  }

  function nearest(pal, r, g, b) {
    var best = 0, bd = Infinity;
    for (var i = 0; i < pal.length; i++) {
      var p = pal[i], dr = r - p[0], dg = g - p[1], db = b - p[2];
      var d = dr * dr * 2 + dg * dg * 4 + db * db * 3;
      if (d < bd) { bd = d; best = i; if (d === 0) break; }
    }
    return best;
  }

  /* Returns {palette (length 1<<bits), indices}. Index 0 is reserved for transparency when needed. */
  function quantize(data, w, h, bits, dither, hasT) {
    var size = 1 << bits, off = hasT ? 1 : 0;
    var real = medianCut(data, size - off);
    var palette = [];
    if (hasT) palette.push([0, 0, 0]);
    for (var i = 0; i < real.length; i++) palette.push(real[i]);
    while (palette.length < size) palette.push([0, 0, 0]);
    var indices = new Uint8Array(w * h);

    if (dither && dither !== 'none') {
      var buf = new Float32Array(w * h * 3);
      for (var p = 0; p < w * h; p++) { buf[p * 3] = data[p * 4]; buf[p * 3 + 1] = data[p * 4 + 1]; buf[p * 3 + 2] = data[p * 4 + 2]; }
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          var pi = y * w + x;
          if (data[pi * 4 + 3] < 128) { indices[pi] = 0; continue; }
          var r = clamp(buf[pi * 3]), g = clamp(buf[pi * 3 + 1]), b = clamp(buf[pi * 3 + 2]);
          var k = nearest(real, r, g, b), pc = real[k];
          indices[pi] = k + off;
          var er = r - pc[0], eg = g - pc[1], eb = b - pc[2];
          var spread = function (xx, yy, f) {
            if (xx < 0 || xx >= w || yy >= h) return;
            var q = (yy * w + xx) * 3;
            buf[q] += er * f; buf[q + 1] += eg * f; buf[q + 2] += eb * f;
          };
          spread(x + 1, y, 7 / 16); spread(x - 1, y + 1, 3 / 16); spread(x, y + 1, 5 / 16); spread(x + 1, y + 1, 1 / 16);
        }
      }
    } else {
      var cache = new Map();
      for (var t = 0; t < w * h; t++) {
        if (data[t * 4 + 3] < 128) { indices[t] = 0; continue; }
        var rr = data[t * 4], gg = data[t * 4 + 1], bb = data[t * 4 + 2];
        var key = (rr << 16) | (gg << 8) | bb, v = cache.get(key);
        if (v === undefined) { v = nearest(real, rr, gg, bb) + off; cache.set(key, v); }
        indices[t] = v;
      }
    }
    return { palette: palette, indices: indices };
  }

  /* data: RGBA Uint8ClampedArray, size x size. Returns {bytes, preview}. */
  function encodeDIB(data, size, bits, dither) {
    var w = size, h = size, n = w * h;
    var maskStride = ((w + 31) >> 5) << 2;
    var opaque = new Uint8Array(n), anyT = false;
    for (var i = 0; i < n; i++) { opaque[i] = data[i * 4 + 3] >= 128 ? 1 : 0; if (!opaque[i]) anyT = true; }

    var palette = null, indices = null;
    var preview = new Uint8ClampedArray(n * 4);
    if (bits <= 8) {
      var q = quantize(data, w, h, bits, dither, anyT);
      palette = q.palette; indices = q.indices;
      for (var a = 0; a < n; a++) {
        if (!opaque[a]) continue;
        var pc = palette[indices[a]];
        preview[a * 4] = pc[0]; preview[a * 4 + 1] = pc[1]; preview[a * 4 + 2] = pc[2]; preview[a * 4 + 3] = 255;
      }
    } else if (bits === 32) {
      preview.set(data);
    } else {
      for (var c = 0; c < n; c++) {
        if (!opaque[c]) continue;
        preview[c * 4] = data[c * 4]; preview[c * 4 + 1] = data[c * 4 + 1]; preview[c * 4 + 2] = data[c * 4 + 2]; preview[c * 4 + 3] = 255;
      }
    }

    var palCount = bits <= 8 ? (1 << bits) : 0;
    var rowStride = bits === 32 ? w * 4 : bits === 24 ? ((w * 3 + 3) & ~3) : bits === 8 ? ((w + 3) & ~3) : ((((w + 1) >> 1) + 3) & ~3);
    var xorSize = rowStride * h, andSize = maskStride * h;
    var out = new Uint8Array(40 + palCount * 4 + xorSize + andSize);
    var dv = new DataView(out.buffer);
    dv.setUint32(0, 40, true);
    dv.setInt32(4, w, true);
    dv.setInt32(8, h * 2, true);
    dv.setUint16(12, 1, true);
    dv.setUint16(14, bits, true);
    dv.setUint32(20, xorSize + andSize, true);
    dv.setUint32(32, palCount, true);
    var pos = 40;
    for (var pi = 0; pi < palCount; pi++) {
      var pe = palette[pi] || [0, 0, 0];
      out[pos++] = pe[2]; out[pos++] = pe[1]; out[pos++] = pe[0]; out[pos++] = 0;
    }
    var xorStart = pos;
    for (var fy = 0; fy < h; fy++) {
      var y = h - 1 - fy, ro = xorStart + fy * rowStride;
      for (var x = 0; x < w; x++) {
        var idx = y * w + x;
        if (bits === 32) {
          var o = ro + x * 4, al = data[idx * 4 + 3];
          if (al) { out[o] = data[idx * 4 + 2]; out[o + 1] = data[idx * 4 + 1]; out[o + 2] = data[idx * 4]; }
          out[o + 3] = al;
        } else if (bits === 24) {
          var o3 = ro + x * 3;
          if (opaque[idx]) { out[o3] = data[idx * 4 + 2]; out[o3 + 1] = data[idx * 4 + 1]; out[o3 + 2] = data[idx * 4]; }
        } else if (bits === 8) {
          out[ro + x] = indices[idx];
        } else {
          var bi = ro + (x >> 1);
          out[bi] |= (x & 1) ? indices[idx] : (indices[idx] << 4);
        }
      }
    }
    var andStart = xorStart + xorSize;
    for (var my = 0; my < h; my++) {
      var yy = h - 1 - my, mo = andStart + my * maskStride;
      for (var mx = 0; mx < w; mx++) {
        if (!opaque[yy * w + mx]) out[mo + (mx >> 3)] |= 0x80 >> (mx & 7);
      }
    }
    return { bytes: out, preview: preview };
  }

  /* entries: [{size, bits, bytes}] sorted ascending. Returns Uint8Array ICO. */
  function buildIco(entries) {
    var n = entries.length, total = 6 + 16 * n, i;
    for (i = 0; i < n; i++) total += entries[i].bytes.length;
    var out = new Uint8Array(total), dv = new DataView(out.buffer);
    dv.setUint16(2, 1, true);
    dv.setUint16(4, n, true);
    var offset = 6 + 16 * n;
    for (i = 0; i < n; i++) {
      var e = entries[i], d = 6 + 16 * i;
      out[d] = e.size >= 256 ? 0 : e.size;
      out[d + 1] = e.size >= 256 ? 0 : e.size;
      out[d + 2] = e.bits === 4 ? 16 : 0;
      dv.setUint16(d + 4, 1, true);
      dv.setUint16(d + 6, e.bits, true);
      dv.setUint32(d + 8, e.bytes.length, true);
      dv.setUint32(d + 12, offset, true);
      out.set(e.bytes, offset);
      offset += e.bytes.length;
    }
    return out;
  }

  var api = { encodeDIB: encodeDIB, buildIco: buildIco };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.IcoEncoder = api;
})(typeof self !== 'undefined' ? self : this);
