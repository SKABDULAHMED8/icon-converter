﻿# Icon Converter launcher and command line tool (Windows PowerShell 5.1+)
# No arguments or --gui : open the converter window.   See --help for the command line mode.

$ErrorActionPreference = 'Stop'
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = Join-Path $env:LOCALAPPDATA 'IconConverter\error.log'

function Write-Log($m) {
    try {
        $d = Split-Path $LogFile
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
        Add-Content -Path $LogFile -Value ("{0}  {1}" -f (Get-Date -Format s), $m)
    } catch {}
}

function Show-Help {
@"
Icon Converter

  iconconv                       Open the converter window
  iconconv --offline             Open the page directly in Chrome (no save-path or shortcut features)
  iconconv <image> [options]     Convert an image without opening a window

Options
  -o, --out <folder>     Folder to save into (default: current folder)
  -n, --name <name>      File name without extension (default: <image>Icon)
  -s, --sizes <list>     Comma separated sizes (default: 16,24,32,48,64,128,256)
  --shortcut <target>    Also create <name>Shortcut.lnk that points to <target> and uses the icon
  --desktop              Put that shortcut on the Desktop instead of the output folder
  -h, --help             Show this help

Examples
  iconconv logo.png
  iconconv logo.png -o D:\Icons -s 16,32,48,256
  iconconv logo.png -n appIcon --shortcut "C:\Tools\app.exe" --desktop

CLI mode reads PNG, JPG, GIF, BMP, TIFF and ICO. Use the window for SVG, WEBP and HEIC.
"@ | Write-Host
}

function Clean-Name([string]$n) {
    $n = [regex]::Replace($n, '[<>:"/\\|?*\x00-\x1f]', '')
    $n = [regex]::Replace($n, '\.(ico|lnk)$', '', 'IgnoreCase').Trim().TrimEnd('.', ' ')
    if ([string]::IsNullOrWhiteSpace($n)) { $n = 'image' }
    return $n
}

function Expand-UserPath([string]$p) {
    $p = $p.Trim().Trim('"')
    if ($p -eq '~' -or $p.StartsWith('~\') -or $p.StartsWith('~/')) { $p = $env:USERPROFILE + $p.Substring(1) }
    return [Environment]::ExpandEnvironmentVariables($p)
}

function Camel-Case([string]$s) {
    $parts = [regex]::Split($s, '[^A-Za-z0-9]+') | Where-Object { $_ }
    if (-not $parts) { return 'image' }
    $out = ''
    for ($i = 0; $i -lt $parts.Count; $i++) {
        $p = $parts[$i]
        if ($i -eq 0) { $out += $p.Substring(0, 1).ToLower() + $p.Substring(1) }
        else { $out += $p.Substring(0, 1).ToUpper() + $p.Substring(1) }
    }
    return $out
}

function New-Shortcut([string]$dir, [string]$name, [string]$target, [string]$icon) {
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    if ($target -match '^[a-zA-Z][a-zA-Z0-9+.-]*://') {
        $path = Join-Path $dir ($name + '.url')
        $lines = @('[InternetShortcut]', "URL=$target", "IconFile=$icon", 'IconIndex=0')
        [System.IO.File]::WriteAllLines($path, $lines)
        return $path
    }
    $path = Join-Path $dir ($name + '.lnk')
    $sh = New-Object -ComObject WScript.Shell
    $lnk = $sh.CreateShortcut($path)
    $lnk.TargetPath = $target
    if (Test-Path -LiteralPath $target -PathType Leaf) { $lnk.WorkingDirectory = Split-Path -Parent $target }
    $lnk.IconLocation = "$icon,0"
    $lnk.Save()
    [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($sh)
    return $path
}

# ---------------------------------------------------------------- CLI conversion
function Convert-ToIco([string]$imagePath, [int[]]$sizes, [string]$outFile) {
    Add-Type -AssemblyName System.Drawing
    $src = [System.Drawing.Image]::FromFile($imagePath)
    try {
        $entries = New-Object System.Collections.ArrayList
        foreach ($s in ($sizes | Sort-Object -Unique)) {
            $bmp = New-Object System.Drawing.Bitmap $s, $s, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
            $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
            $g.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
            $k = [Math]::Min($s / $src.Width, $s / $src.Height)
            $w = [Math]::Max(1, [int][Math]::Round($src.Width * $k))
            $h = [Math]::Max(1, [int][Math]::Round($src.Height * $k))
            $g.DrawImage($src, [int](($s - $w) / 2), [int](($s - $h) / 2), $w, $h)
            $g.Dispose()
            $ms = New-Object System.IO.MemoryStream
            $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
            [void]$entries.Add(@{ Size = $s; Bytes = $ms.ToArray() })
            $ms.Dispose(); $bmp.Dispose()
        }
        $out = New-Object System.IO.MemoryStream
        $bw = New-Object System.IO.BinaryWriter $out
        $bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$entries.Count)
        $offset = 6 + 16 * $entries.Count
        foreach ($e in $entries) {
            $dim = if ($e.Size -ge 256) { 0 } else { $e.Size }
            $bw.Write([byte]$dim); $bw.Write([byte]$dim); $bw.Write([byte]0); $bw.Write([byte]0)
            $bw.Write([uint16]1); $bw.Write([uint16]32)
            $bw.Write([uint32]$e.Bytes.Length); $bw.Write([uint32]$offset)
            $offset += $e.Bytes.Length
        }
        foreach ($e in $entries) { $bw.Write($e.Bytes) }
        $bw.Flush()
        [System.IO.File]::WriteAllBytes($outFile, $out.ToArray())
    } finally { $src.Dispose() }
}

function Invoke-Cli([string[]]$a) {
    $image = $null; $outDir = (Get-Location).Path; $name = $null
    $sizes = @(16, 24, 32, 48, 64, 128, 256); $shortcut = $null; $desktop = $false
    for ($i = 0; $i -lt $a.Count; $i++) {
        switch -regex ($a[$i]) {
            '^(-o|--out)$'      { $i++; $outDir = Expand-UserPath $a[$i]; continue }
            '^(-n|--name)$'     { $i++; $name = Clean-Name $a[$i]; continue }
            '^(-s|--sizes)$'    { $i++; $sizes = $a[$i].Split(',') | ForEach-Object { [int]$_.Trim() }; continue }
            '^--shortcut$'      { $i++; $shortcut = Expand-UserPath $a[$i]; continue }
            '^--desktop$'       { $desktop = $true; continue }
            '^-'                { throw "Unknown option $($a[$i]). Run iconconv --help." }
            default             { if (-not $image) { $image = Expand-UserPath $a[$i] } else { throw "Unexpected argument $($a[$i])." } }
        }
    }
    if (-not $image) { Show-Help; return }
    if (-not (Test-Path -LiteralPath $image -PathType Leaf)) { throw "Image not found: $image" }
    foreach ($s in $sizes) { if ($s -lt 8 -or $s -gt 512) { throw "Size $s is out of range (8 to 512)." } }
    if (-not $name) { $name = (Camel-Case ([IO.Path]::GetFileNameWithoutExtension($image))) + 'Icon' }
    if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Force -Path $outDir | Out-Null }
    $outDir = (Resolve-Path -LiteralPath $outDir).Path
    $icoPath = Join-Path $outDir ($name + '.ico')
    Convert-ToIco $image $sizes $icoPath
    Write-Host "Saved $icoPath"
    if ($shortcut) {
        $scName = if ($name -match 'Icon$') { $name.Substring(0, $name.Length - 4) + 'Shortcut' } else { $name + 'Shortcut' }
        $scDir = if ($desktop) { [Environment]::GetFolderPath('Desktop') } else { $outDir }
        Write-Host ("Saved " + (New-Shortcut $scDir $scName $shortcut $icoPath))
    }
}

# ---------------------------------------------------------------- GUI server
function Find-Browser {
    $c = New-Object System.Collections.ArrayList
    foreach ($hive in 'HKLM', 'HKCU') {
        try {
            $v = (Get-ItemProperty "${hive}:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" -ErrorAction Stop).'(default)'
            if ($v) { [void]$c.Add($v) }
        } catch {}
    }
    foreach ($p in @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")) { [void]$c.Add($p) }
    foreach ($p in $c) { if ($p -and (Test-Path -LiteralPath $p)) { return $p } }
    return $null
}

function Start-AppWindow([string]$url) {
    $b = Find-Browser
    if ($b) { Start-Process -FilePath $b -ArgumentList @("--app=$url", '--window-size=1220,900') }
    else { Start-Process $url }
}

function Send-Json($ctx, $obj, [int]$code = 200) {
    $json = $obj | ConvertTo-Json -Depth 5 -Compress
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $ctx.Response.StatusCode = $code
    $ctx.Response.ContentType = 'application/json; charset=utf-8'
    $ctx.Response.ContentLength64 = $bytes.Length
    $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    $ctx.Response.OutputStream.Close()
}

function Show-FolderDialog([string]$start) {
    Add-Type -AssemblyName System.Windows.Forms
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Opacity = 0; StartPosition = 'CenterScreen' }
    $owner.Show()
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = 'Choose where to save the icon'
    $d.ShowNewFolderButton = $true
    $s = Expand-UserPath $start
    if ($s -and (Test-Path -LiteralPath $s -PathType Container)) { $d.SelectedPath = $s }
    $r = $d.ShowDialog($owner)
    $owner.Close()
    if ($r -eq [System.Windows.Forms.DialogResult]::OK) { return $d.SelectedPath }
    return $null
}

function Show-FileDialog([string]$start) {
    Add-Type -AssemblyName System.Windows.Forms
    $owner = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Opacity = 0; StartPosition = 'CenterScreen' }
    $owner.Show()
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.Title = 'Choose what the shortcut opens'
    $d.Filter = 'Apps and files (*.*)|*.*'
    $d.DereferenceLinks = $false
    $s = Expand-UserPath $start
    if ($s -and (Test-Path -LiteralPath $s -PathType Leaf)) { $d.FileName = $s }
    $r = $d.ShowDialog($owner)
    $owner.Close()
    if ($r -eq [System.Windows.Forms.DialogResult]::OK) { return $d.FileName }
    return $null
}

function Start-Gui {
    $index = Join-Path $AppDir 'index.html'
    if (-not (Test-Path -LiteralPath $index)) { throw "index.html not found next to the script." }

    $tcp = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Loopback), 0
    $tcp.Start(); $port = $tcp.LocalEndpoint.Port; $tcp.Stop()
    $token = [Guid]::NewGuid().ToString('N')
    $base = "http://127.0.0.1:$port"

    $listener = New-Object System.Net.HttpListener
    $listener.Prefixes.Add("$base/")
    $listener.Start()
    Start-AppWindow "$base/"

    $mime = @{ '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'; '.png' = 'image/png'; '.ico' = 'image/x-icon' }
    $defaultDir = [Environment]::GetFolderPath('MyPictures')
    if (-not (Test-Path -LiteralPath $defaultDir)) { $defaultDir = [Environment]::GetFolderPath('Desktop') }
    $lastPing = Get-Date; $seenPing = $false

    while ($listener.IsListening) {
        $task = $listener.GetContextAsync()
        while (-not $task.AsyncWaitHandle.WaitOne(1000)) {
            if ($seenPing -and ((Get-Date) - $lastPing).TotalSeconds -gt 25) { $listener.Stop(); return }
            if (-not $seenPing -and ((Get-Date) - $lastPing).TotalSeconds -gt 120) { $listener.Stop(); return }
        }
        $ctx = $task.Result
        try {
            $req = $ctx.Request
            if ($req.Url.Host -ne '127.0.0.1') { Send-Json $ctx @{ ok = $false; error = 'Bad host' } 403; continue }
            $path = $req.Url.AbsolutePath

            if ($req.HttpMethod -eq 'GET') {
                if ($path -eq '/') {
                    $html = [IO.File]::ReadAllText($index, [Text.Encoding]::UTF8).Replace('__IC_TOKEN__', $token)
                    $bytes = [Text.Encoding]::UTF8.GetBytes($html); $ctx.Response.ContentType = $mime['.html']
                } else {
                    $rel = $path.TrimStart('/').Replace('/', '\')
                    $full = [IO.Path]::GetFullPath((Join-Path $AppDir $rel))
                    $ext = [IO.Path]::GetExtension($full).ToLower()
                    if (-not $full.StartsWith($AppDir, [StringComparison]::OrdinalIgnoreCase) -or -not $mime.ContainsKey($ext) -or $ext -eq '.html' -or -not (Test-Path -LiteralPath $full -PathType Leaf)) {
                        $ctx.Response.StatusCode = 404; $ctx.Response.Close(); continue
                    }
                    $bytes = [IO.File]::ReadAllBytes($full); $ctx.Response.ContentType = $mime[$ext]
                }
                $ctx.Response.ContentLength64 = $bytes.Length
                $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
                $ctx.Response.OutputStream.Close()
                continue
            }

            if ($req.HttpMethod -ne 'POST' -or $req.Headers['X-IC-Token'] -ne $token) { Send-Json $ctx @{ ok = $false; error = 'Not allowed' } 403; continue }
            $raw = (New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)).ReadToEnd()
            $body = if ($raw) { $raw | ConvertFrom-Json } else { [pscustomobject]@{} }

            switch ($path) {
                '/api/ping' { $lastPing = Get-Date; $seenPing = $true; Send-Json $ctx @{ ok = $true; defaultDir = $defaultDir } }
                '/api/browse' { Send-Json $ctx @{ ok = $true; path = (Show-FolderDialog $body.start) } }
                '/api/browsefile' { Send-Json $ctx @{ ok = $true; path = (Show-FileDialog $body.start) } }
                '/api/save' {
                    $dir = Expand-UserPath ([string]$body.dir)
                    if (-not [IO.Path]::IsPathRooted($dir)) { Send-Json $ctx @{ ok = $false; error = 'Enter a full folder path such as C:\Users\you\Pictures.' }; continue }
                    $name = (Clean-Name ([string]$body.name)) + '.ico'
                    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                    $dir = (Resolve-Path -LiteralPath $dir).Path
                    $file = Join-Path $dir $name
                    if ((Test-Path -LiteralPath $file) -and -not $body.overwrite) { Send-Json $ctx @{ ok = $false; exists = $true; path = $file }; continue }
                    [IO.File]::WriteAllBytes($file, [Convert]::FromBase64String([string]$body.data))
                    Send-Json $ctx @{ ok = $true; path = $file; dir = $dir }
                }
                '/api/shortcut' {
                    $dir = if ($body.desktop) { [Environment]::GetFolderPath('Desktop') } else { Expand-UserPath ([string]$body.dir) }
                    $target = ([string]$body.target).Trim().Trim('"')
                    if ($target -notmatch '^[a-zA-Z][a-zA-Z0-9+.-]*://') { $target = Expand-UserPath $target }
                    $made = New-Shortcut $dir (Clean-Name ([string]$body.name)) $target ([string]$body.icon)
                    Send-Json $ctx @{ ok = $true; path = $made }
                }
                '/api/reveal' {
                    $p = [string]$body.path
                    if (Test-Path -LiteralPath $p) { Start-Process explorer.exe -ArgumentList "/select,`"$p`"" }
                    Send-Json $ctx @{ ok = $true }
                }
                default { Send-Json $ctx @{ ok = $false; error = 'Unknown request' } 404 }
            }
        } catch {
            Write-Log $_.Exception.Message
            try { Send-Json $ctx @{ ok = $false; error = $_.Exception.Message } 500 } catch {}
        }
    }
}

# ---------------------------------------------------------------- entry point
try {
    $argv = @($args)
    if ($argv.Count -eq 0 -or $argv[0] -eq '--gui') { Start-Gui }
    elseif ($argv[0] -in @('-h', '--help', '/?', '-?')) { Show-Help }
    elseif ($argv[0] -eq '--offline') {
        $b = Find-Browser
        $url = ([Uri](Join-Path $AppDir 'index.html')).AbsoluteUri
        if ($b) { Start-Process -FilePath $b -ArgumentList @("--app=$url", '--window-size=1220,900') } else { Start-Process $url }
    }
    else { Invoke-Cli $argv }
} catch {
    Write-Log $_.Exception.Message
    Write-Host ("iconconv: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
