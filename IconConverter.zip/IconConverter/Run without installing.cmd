@echo off
rem Opens the page straight in Chrome, no install needed.
wscript.exe //B "%~dp0app\launch.vbs"
