﻿$ErrorActionPreference = 'SilentlyContinue'
$dest = Join-Path $env:LOCALAPPDATA 'IconConverter'
$bin  = Join-Path $dest 'bin'
$cur = [Environment]::GetEnvironmentVariable('Path', 'User')
if ($cur) {
    $new = (($cur -split ';') | Where-Object { $_ -and $_ -ne $bin }) -join ';'
    [Environment]::SetEnvironmentVariable('Path', $new, 'User')
}
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Icon Converter.lnk') -Force
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) 'Icon Converter.lnk') -Force
Start-Process cmd.exe -WindowStyle Hidden -ArgumentList "/c ping -n 3 127.0.0.1 >nul & rmdir /s /q `"$dest`""
Write-Host 'Icon Converter was removed.' -ForegroundColor Green
