ICON CONVERTER  -  image to Windows .ico, works fully offline
==============================================================

INSTALL (once)
  1. Unzip this folder anywhere.
  2. Double-click Install.cmd.  No admin rights needed.
  3. Open a NEW Command Prompt or PowerShell window and type:   iconconv

  The installer copies the app to %LOCALAPPDATA%\IconConverter, adds its "bin"
  folder to your user PATH (so "iconconv" is recognized everywhere), and creates
  "Icon Converter" shortcuts on the Desktop and Start Menu with the app icon.
  Windows only reads PATH when a window starts, so windows opened before the
  install need to be reopened.

USE THE WINDOW
  iconconv                 opens the converter in Chrome (Edge if Chrome is missing)
  iconconv --offline       opens app\index.html directly (no installer, no save-path box)

  - Select, drop or paste (Ctrl+V) an image: PNG, JPG, WEBP, HEIC, GIF, TIFF, BMP, SVG, ICO
  - Crop, rotate, flip, pick sizes, rounded corners, background, BMP/PNG format
  - File name defaults to camelCase, e.g. "My Logo.png" -> myLogoIcon.ico
  - Save to: paste a folder path from File Explorer, or press Select folder
  - Add a shortcut that uses this icon: tick the box, choose what it opens, and
    it creates myLogoShortcut.lnk next to the icon (or on the Desktop)

USE THE COMMAND LINE
  iconconv logo.png
  iconconv logo.png -o D:\Icons -s 16,32,48,256
  iconconv logo.png -n appIcon --shortcut "C:\Tools\app.exe" --desktop
  iconconv --help
  (Command line mode reads PNG, JPG, GIF, BMP, TIFF, ICO and writes PNG-compressed
   icons. Use the window for SVG, WEBP, HEIC, BMP 4/8/24/32-bit and rounded corners.)

PHONE OR TABLET (no install)
  Copy IconConverter-Phone.html to the phone and open it in Chrome. It is one
  self-contained file that works offline. It downloads the .ico to the phone;
  save-to-path and shortcuts are Windows only.

WITHOUT INSTALLING
  Double-click "Run without installing.cmd", or open app\index.html in Chrome.
  In a plain Chrome tab the page can save into a folder you pick once (Chrome
  remembers it) but cannot take a pasted path or create .lnk shortcuts; the
  desktop launcher can.

UNINSTALL
  Double-click Uninstall.cmd.

NOTES
  - Nothing is uploaded. The launcher only listens on 127.0.0.1 with a random
    port and a per-run token, and exits when you close the window.
  - If something fails, see %LOCALAPPDATA%\IconConverter\error.log
  - Requires Windows 10/11 (Windows PowerShell 5.1 is built in).
