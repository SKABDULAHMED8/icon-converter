﻿# Installs Icon Converter for the current user (no admin rights needed).
$ErrorActionPreference = 'Stop'
$src  = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $env:LOCALAPPDATA 'IconConverter'

Write-Host "Installing to $dest"
if (-not (Test-Path $dest)) { New-Item -ItemType Directory -Force -Path $dest | Out-Null }
foreach ($d in 'app', 'bin') {
    $t = Join-Path $dest $d
    if (Test-Path $t) { Remove-Item -Recurse -Force $t }
    Copy-Item -Recurse -Force (Join-Path $src $d) $t
}
Get-ChildItem -Recurse -File $dest | Unblock-File

# Add bin folder to the user PATH so "iconconv" works in CMD and PowerShell
$bin = Join-Path $dest 'bin'
$cur = [Environment]::GetEnvironmentVariable('Path', 'User')
if (-not $cur) { $cur = '' }
if (-not (($cur -split ';') -contains $bin)) {
    $new = (($cur.TrimEnd(';') + ';' + $bin)).TrimStart(';')
    [Environment]::SetEnvironmentVariable('Path', $new, 'User')
    Write-Host 'Added to PATH.'
}
$env:Path = $env:Path + ';' + $bin

# Desktop and Start Menu shortcuts that use the app icon
$icon = Join-Path $dest 'app\icon.ico'
$vbs  = Join-Path $dest 'app\launch.vbs'
$sh = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))
foreach ($p in $places) {
    $l = $sh.CreateShortcut((Join-Path $p 'Icon Converter.lnk'))
    $l.TargetPath = Join-Path $env:SystemRoot 'System32\wscript.exe'
    $l.Arguments = "//B `"$vbs`""
    $l.WorkingDirectory = Join-Path $dest 'app'
    $l.IconLocation = "$icon,0"
    $l.Description = 'Convert images to Windows icons'
    $l.Save()
}

Write-Host ''
Write-Host 'Done. Open a NEW Command Prompt or PowerShell window and run:  iconconv' -ForegroundColor Green
Write-Host 'Help:  iconconv --help'
